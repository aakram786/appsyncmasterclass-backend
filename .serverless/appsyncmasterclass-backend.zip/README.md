# appsyncmasterclass-backend
Backend for the AppSync Masterclass Demo App
